<div class="footer">
	<div class="container">
		<center><b class="copyright">&copy; {{ date('Y') }} - Cybrarian in the Vegetable Bowl of Pangasinan; Municipality of Villasis. </b> All rights reserved.</center>
	</div>
</div>
