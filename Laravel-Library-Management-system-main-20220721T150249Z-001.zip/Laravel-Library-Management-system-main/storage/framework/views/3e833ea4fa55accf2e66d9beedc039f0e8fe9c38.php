<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="">
    <meta name="description" content="">
    <meta name="keywords" content="">

    <link rel="shortcut icon" href="">
    <link rel="image_src" href="" />
    <link rel="canonical" href="" />

    <title>CYBRARIAN Management System</title>

    <link type="text/css" href="<?php echo e(asset('static/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link type="text/css" href="<?php echo e(asset('static/bootstrap/css/bootstrap-responsive.min.css')); ?>" rel="stylesheet">
    <link type="text/css" href="<?php echo e(asset('static/css/theme.css')); ?>" rel="stylesheet">
    <link type="text/css" href="<?php echo e(asset('static/images/icons/css/font-awesome.css')); ?>" rel="stylesheet">
    <link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>

    <?php echo $__env->make('common.script_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>

    <style>
        .module-head{
            background-color: #DC143C;
            color:#fff;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            text-transform: uppercase;
            font-style: bold;
        }
        .module-head h3{
            color:#fff;
        }

        .widget-menu{
            background: #DC143C !important;
            color:#fff;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            text-transform: uppercase;
            font-style: bold;
        }
        .navbar-inner{
            background: #DC143C !important;
            color:#fff;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            text-transform: uppercase;
            font-style: bold;
        }
    </style>


    <?php echo $__env->make('account.navigation_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('account.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('account.navigation_bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('static/scripts/jquery-1.9.1.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('static/scripts/jquery-ui-1.10.1.custom.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('static/bootstrap/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('static/scripts/underscore-min.js')); ?>" type="text/javascript"></script>

<script src="<?php echo e(asset('static/custom/js/script.common.js')); ?>" type="text/javascript"></script>

<?php echo $__env->make('common.script_bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script type="text/template" id="alert_box">
    <?php echo $__env->make('underscore.alert_box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</script>

<script>
        $(document).ready(function(){ 
        $("input").attr("autocomplete", "off");
    });
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel-Library-Management-system-main\resources\views/account/index.blade.php ENDPATH**/ ?>