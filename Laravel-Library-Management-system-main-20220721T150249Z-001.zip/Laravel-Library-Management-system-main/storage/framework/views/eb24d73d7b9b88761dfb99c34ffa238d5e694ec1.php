<style>
	.wrapper{
		background-image: url(<?php echo e(asset("")); ?>);
		background-color: #cccccc;
		height: 500px;
		background-position: center;
		background-repeat: no-repeat;
		background-size: cover;
		position: relative;
	}

    .wrapper1{
		background-image: url(<?php echo e(asset('')); ?>);
		background-color: #cccccc;
		height: 500px;
		background-position: center;
		background-repeat: no-repeat;
		background-size: cover;
		position: relative;
	}

</style><?php /**PATH C:\xampp\htdocs\Laravel-Library-Management-system-main\resources\views/account/style.blade.php ENDPATH**/ ?>