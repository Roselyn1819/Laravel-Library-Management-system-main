<div class="footer">
	<div class="container">
		<center><b class="copyright">&copy; <?php echo e(date('Y')); ?> - Cybrarian in the Vegetable Bowl of Pangasinan; Municipality of Villasis. </b> All rights reserved.</center>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel-Library-Management-system-main\resources\views/layout/template_footer.blade.php ENDPATH**/ ?>