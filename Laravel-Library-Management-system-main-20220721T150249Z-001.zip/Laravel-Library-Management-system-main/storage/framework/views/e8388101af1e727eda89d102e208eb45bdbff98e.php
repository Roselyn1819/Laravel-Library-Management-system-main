<div class="footer">
	<div class="container">
		<b class="copyright">&copy; <?php echo e(date('Y')); ?> - Cybrarian in the Vegetable Bowl of Pangasinan; Municipality of Villasis </b> All rights reserved.
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel-Library-Management-system-main\resources\views/account/navigation_bottom.blade.php ENDPATH**/ ?>